# Project brief

## Title
Community event evidence brief

## Original idea
Help our community group understand options for reducing waste at events.

## Desired outcome
A short evidence brief that separates observations from assumptions and lists what we need to learn before choosing a trial.

## Who benefits
A community group preparing a discussion about its next research questions.

## Context
Fictional tutorial exercise. No baseline or impact measurement is available. The goal is a careful brief and next questions, not a real-world recommendation.
