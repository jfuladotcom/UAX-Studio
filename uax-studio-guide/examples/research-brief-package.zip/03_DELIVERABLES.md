# Expected agent outputs

## Source organizer
- SOURCE_INDEX.md: Source IDs, origin, stated date, note location, evidence type, and missing context.

## Evidence analyst
- EVIDENCE_MAP.md: Claims, source IDs, evidence type, limits, and open questions.

## Brief writer
- DECISION_BRIEF.md: A concise discussion brief with source references, uncertainties, and next questions.

## Reviewer
- REVIEW.md: Traceable issues, requested corrections, remaining limits, and a recommendation for the human reviewer.

These are requested outputs, not completed files.
