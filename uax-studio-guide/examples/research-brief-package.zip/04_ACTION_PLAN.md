# Build sequence

1. Source organizer — AGENT_01_source-organizer.md
2. Evidence analyst — AGENT_02_evidence-analyst.md
3. Brief writer — AGENT_03_brief-writer.md
4. Reviewer — AGENT_04_reviewer.md

See ECOSYSTEM.md for connection labels, review loops, and approval requirements.
