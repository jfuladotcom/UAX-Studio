# Handoffs outside this export

All defined handoffs for these agents are included.

Never invent the outputs of an agent that is not present.
