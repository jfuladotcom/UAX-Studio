# Quality checks

## Source organizer
Every entry traces to a supplied note. No invented details. Missing dates and fictional practice content remain explicitly labelled.

## Evidence analyst
Each claim has a source or is labelled as an assumption. No quantitative effect or certainty exceeds the notes. The missing baseline and resources remain visible.

## Brief writer
A reader can distinguish source evidence from interpretation. No invented impact claims. Next questions relate to a real gap in the notes.

## Reviewer
Each issue points to a passage or source. The review addresses both factual support and the agreed brief goal. Remaining uncertainty is explicit.

## Structural review
Core definitions are present; review their content.

These are structural checks, not an assessment of feasibility, factual accuracy, safety, or project success.
