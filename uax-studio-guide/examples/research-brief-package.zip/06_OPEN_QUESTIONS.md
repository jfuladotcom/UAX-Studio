# Questions and answers

## What baseline and success measure would a real trial use?

Unresolved. The brief should explain why this information is needed before selecting a real trial.

## What budget, time, and operational capacity are available?

Unresolved. Record the question instead of assuming resources.

## What should this exercise produce?

A source index, evidence map, discussion brief, and quality review based only on fictional practice notes.
