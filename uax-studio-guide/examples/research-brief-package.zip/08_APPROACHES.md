# Exploration and alternatives

These are untested approaches, not findings or executed work. Only the active agents in the main project define the current workflow. Alternative drafts are retained for comparison; do not execute all of them.

## Available information
Fictional interview notes and suggestions from a small community group.

## What is uncertain
No measured baseline, confirmed budget, operational capacity, or tested impact is available.

## Evidence brief — chosen as a starting point
Origin: user

Organize the available notes and identify what the group should learn before choosing a trial.

Best for: Understanding what existing notes support and where information is missing.

Information needed: The available notes and a clear question.

Main limitation: Cannot establish whether an intervention works.

Assumptions: A source-grounded brief would help the group plan its next discussion. The notes are fictional.

Draft roles: No structure prescribed yet.

## Trial planning — alternative
Origin: user

Define a small trial and what it would measure after the group has the required context.

Best for: Planning the next real measurements.

Information needed: A baseline, agreed success measure, budget, and operational constraints.

Main limitation: Needs information that is not available in this exercise.

Assumptions: The group may later have capacity for a trial. This is untested and is not the chosen tutorial route.

Draft roles: No structure prescribed yet.
